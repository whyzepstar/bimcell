// Pia Changes Defect: 19967
jQuery(function(){
	// Disable Context Menu For Footer And Navbar Link
	jQuery(document).on('contextmenu', '.footer a, .navbar a', function(e) {
	    e.preventDefault();
	    e.stopPropagation();
	});
});

var isAnd = navigator.userAgent.toLowerCase().indexOf("android") > -1 ? true : false,
	isIOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false ),
	isArm = navigator.platform.toLowerCase().indexOf("arm") > -1 ? true : false;
// Pia Changes End Defect: 19967

function getPasteData(e)
{
	var clipboard = (e.originalEvent || e).clipboardData;
	
	if ( clipboard === undefined || clipboard === null )
	{
		return window.clipboardData.getData("text");
	}
	else
	{
		return clipboard.getData("text/plain");
	}
	
	return;
}

function customInputController()
{
	var lastKeydownEvent;

	$('.beforeAfter').each(function(){
		
		var self = $(this),
			render = self.data('beforeAfterRendered');
		
		if ( render !== true )
		{
			self.bind('keyup keydown', function(e){

				var __self = $(this),
					__maxLength = parseInt(__self.attr('maxlength')),
					__before = __self.attr('data-before'),
					__after = __self.attr('data-after'),
					__length = __self.val().length,
					__caret = __self.caret();
				
				var eventType = e.type,
					ctrlKey = e.ctrlKey,
					shiftKey = e.shiftKey,
					altKey = e.altKey,
					keyCode = e.keyCode,
					charCode = e.charCode;
				
				if ( eventType === "keydown" )
				{
					lastKeydownEvent = {
						eventType : eventType,
						ctrlKey : ctrlKey,
						shiftKey : shiftKey,
						altKey : altKey,
						keyCode : keyCode,
						charCode : charCode
					};
				}

				if(eventType == "keyup"){
					if(__self.attr("maxlength") != "" && __self.attr("data-after") != ""){
						if(__self.val().length == parseInt(__self.attr("maxlength")) && keyCode != 8)
							jQuery("#" + __self.attr("data-after")).focus();
					}
				}
				
				var leftOrRight = $.inArray(keyCode, [37, 39]) !== -1 && !ctrlKey && !altKey && !shiftKey;
				
				if ( leftOrRight )
				{
					if ( eventType === "keydown" )
					{
						if ( __caret === 0 && __before && keyCode === 37 )
						{
							e.preventDefault();
							$(document.getElementById(__before)).focus();
						}
						else if ( __caret >= __maxLength && __after && keyCode === 39 )
						{
							e.preventDefault();
							$(document.getElementById(__after)).focus();
						}
					}
				}
				else
				{
					var deleteOrBackspace = $.inArray(keyCode, [8, 46]) !== -1 && !ctrlKey;
					
					if ( eventType === "keydown" && deleteOrBackspace && __length === 0 && __before )
					{
						e.preventDefault();
						$(document.getElementById(__before)).focus();
					}
					else
					{
						if ( eventType === "keyup" )
						{
							eventType = lastKeydownEvent.type,
							ctrlKey = lastKeydownEvent.ctrlKey,
							shiftKey = lastKeydownEvent.shiftKey,
							altKey = lastKeydownEvent.altKey,
							keyCode = lastKeydownEvent.keyCode,
							charCode = lastKeydownEvent.charCode;
						}
						
						var controlKeys = ctrlKey || shiftKey || altKey,
							isNoAction = $.inArray(keyCode, [8, 13, 27, 46, 35, 36, 38, 40]) !== -1,
							isClipboard = ($.inArray(charCode, [65, 67, 86, 88]) !== -1 || $.inArray(charCode, [97, 99, 118, 120]) !== -1) && ctrlKey,
							moveOrSelect = $.inArray(keyCode, [37, 38]) !== -1 && (shiftKey || ctrlKey);
						
						if ( controlKeys || isNoAction || isClipboard || moveOrSelect ) return;
						
						if ( __length >= __maxLength && __caret >= __maxLength && __after && keyCode !== 9 )
						{
							e.preventDefault();
							$(document.getElementById(__after)).focus();							
						}
					}
				}
				
			});
			
			self.data('beforeAfterRendered', true);
		}
		
	});
	
	$('.onlyNumeric').each(function(){
		
		// Pia Changes
		var self = $(this),
			render = self.data('onlyNumericRendered'),
			isAndroid = navigator.userAgent.toLowerCase().indexOf("android"),
			isIOS = ( navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false );

		// PIA_CHANGES: BEGIN: DEFECT: 19614
		if( ( isAndroid > -1 || isIOS ) && self.attr("type") != "password"){
			self.attr("type", "number");
		}
		else if( ( isAndroid > -1 || isIOS ) && self.attr("type") == "password" ){
			self.attr("type", "number").css({ "-webkit-text-security": "disc" });
		}
		// PIA_CHANGES: END: DEFECT: 19614
			
		if ( render !== true )
		{	
			var control = function(e){
				var ctrlKey = e.ctrlKey,
					shiftKey = e.shiftKey,
					altKey = e.altKey,
					keyCode = e.keyCode,
					charCode = e.charCode;
					
				var isAllowedKeys = $.inArray(keyCode, [13]) !== -1,
					isNotNumeric = charCode && !( charCode >= 48 && charCode <= 57 ),
					isClipboard = ($.inArray(charCode, [65, 67, 86, 88]) !== -1 || $.inArray(charCode, [97, 99, 118, 120]) !== -1) && ctrlKey;
					
				if ( isNotNumeric && !isClipboard && !isAllowedKeys ) e.preventDefault();
			};

			if(isAndroid > -1){
				self.on("keydown", function(e){
					control(e);
				});
			}
			else{
				self.bind('keypress', function(e){			
					control(e);
				});
			}
			// Pia Changes End
			
			if ( !self.hasClass('disablePaste') )
			{
				self.bind('paste', function(e){
				
					if ( !getPasteData(e).match(/^[0-9]+$/) ) e.preventDefault();
					
				});
			}
			
			self.data('onlyNumericRendered', true);
		}
	
	});
	
	$('.onlyText').each(function(){
	
		var self = $(this),
			render = self.data('onlyTextRendered');
			
		if ( render !== true )
		{
			self.bind('keypress', function(e){
			
				var ctrlKey = e.ctrlKey,
					shiftKey = e.shiftKey,
					altKey = e.altKey,
					keyCode = e.keyCode,
					charCode = e.charCode;
				
				var isNumeric = charCode && ( charCode >= 48 && charCode <= 57 );
				
				if ( isNumeric ) e.preventDefault();
				
			});
			
			if ( !self.hasClass('disablePaste') )
			{
				self.bind('paste', function(e){
				
					if ( getPasteData(e).match(/[0-9]/) ) e.preventDefault();
					
				});
			}				
			
			self.data('onlyTextRendered', true);
		}
	
	});
	
	$('.disablePaste').each(function(){
		
		var self = $(this),
			render = self.data('disablePasteRendered');
		
		if ( render !== true )
		{
			self.bind('paste', function(e){
				e.preventDefault();
			});
			
			self.data('disablePasteRendered', true);
		}
		
	});

	// Pia Changes
	$('.maxLength, [maxlength]').each(function(){

		if($(this).attr('data-maxlength') == '' && $(this).attr('maxlength') == '')
			return;
		else if($(this).attr('data-maxlength') == '' && $(this).attr('maxlength') != '')
			$(this).attr('data-maxlength', $(this).attr('maxlength'));

		var self = $(this),
			maxLength = parseInt(self.attr('data-maxlength')),
			isAndroid = navigator.userAgent.toString().toLowerCase().indexOf("android") > -1 ? true : false;

		if(isAndroid){
			self.on('keydown', function(e){
				if($(this).val().length >= maxLength && e.keyCode != 8 && e.keyCode != 13){
					$(this).blur();
					$(this).val( $(this).val().substr(0, maxLength) );
				}
			});
		}
		else {
			self.on('keypress', function(e){
				if($(this).val().length >= maxLength && e.keyCode != 8 && e.keyCode != 13)
					e.preventDefault();
			});
		}

	});

	$('.turnOffAutoComplete, [autocomplete="off"]').each(function(e){
		this.autocomplete = "off";
	});

	// Pia Changes Defect: 19994
	$('.focusJump').each(function(index){
		var focusTo = $(this).attr('data-focusto');
		$(this).on('keydown', function(e){
			if(e.keyCode == 9){
				e.preventDefault();
				$(focusTo).focus();
			}
		});
	});
	// Pia Changes End Defect: 19994

	// Pia Changes End
}