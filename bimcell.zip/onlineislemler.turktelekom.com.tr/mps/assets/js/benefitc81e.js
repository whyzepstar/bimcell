/**
 * Created by Kafein on 25.11.2015.
 */

function log(message, obj) {
    console.log(message + ":" + JSON.stringify(obj));
}

/**
 * 
 * @param data
 * @returns
 */
function Benefit(data) {
    this.id = data.id || 0;
    this.name = data.name || ""; 
    this.titlex = data.title || "";
    this.image = data.image || "";
    this.text = data.text || "";
    this.showOk = data.showOk || ""; 
    this.showCancel = data.showCancel || "";
    this.benefitAction = data.benefitAction || ""; 
    this.params = data.params || []; 
    this.buttons = data.buttons || []; 
    this.priority = data.order_num || 0; // order_num is encapsulated here with priority property. 
    this.warningMessage = data.warningMessage || ""; 
    this.controlMethod = data.controlMethod || ""; 
    this.cmd = data.cmd || ""; 
    this.type = data.type || ""; 
    

    this.box = $("<div/>");

}


function BenefitManager() {
    this.index = 0;
    this.stop = false;
    this.publisher = {};
    this.benefits = [];
    this.benefitCallbacks = new Array();
    this.defaultCallback = null;

    this.setDefaultCallback = function (callback){
        this.defaultCallback = callback;
    }
    
    
    this.setBenefitCallbacks = function (functionz){
    	log("functionz :",functionz);
        this.benefitCallbacks = functionz;
	}
    
    
    this.findCallbackForBenefit = function (benefit){
        var callback = this.benefitCallbacks[benefit.controlMethod];
        log("benefitCallbacks obj ",callback );
        
        if (typeof callback !== 'function'){
            log("callback could not be found trying default callback for benefit ", benefit.controlMethod);
            if (typeof this.defaultCallback === "function"){
                log("default callback found for benefit: ", benefit.controlMethod);
                callback = this.defaultCallback;
            }else {
                log("There is even no default callback for benefit! :", benefit.controlMethod);
                callback = function (){};
            }
        }
        log("Found callback for benefit ", benefit.controlMethod);
        return callback;
    }

    this.run = function () {
        var benefit = this.benefits[this.index];
        log("Running for benefit ", benefit.id);
        this.runBenefit(benefit, this.findCallbackForBenefit(benefit))

    };


    this.runBenefit = function (benefit, callback) {
        log("RunBenefit Function", benefit.id);
        if (typeof callback === 'function') {

            benefit.box = callback(benefit);
            if (benefit.box) {
                this.publisher.fire({"name": "show", "target": benefit});
            } else {
                this.publisher.fire({"name": "noboxtoshow", target: benefit});
            }
        }else {
            log("callback is not a function so there is a problem for benefit ", benefit.id);
        }

    };

    this.update = function (event) {

        if (event.name == "noboxtoshow"){
            log("There is no box to show benefit: ", event.target.id);
            this.index++;
        }
        if (event.name == "show") {

            for (var i = 0; i < this.benefits.length; i++){
                var benefit = this.benefits[i];
                log("benefit : "+ benefit.id + "event.target.id :"+event.target.id );
                if (benefit.id != event.target.id){
                    if (benefit.box) {
                        log("benefit box is hiding : ", benefit.id);
                        benefit.box.modal('hide');
                    }else {
                        log("There is no box for benefit so does not hide: ", benefit.id);
                    }
                }else {
                    log("Benefit box showing: ", benefit);
                  
                    benefit.box.modal('show');
                    
                
                    return;
                }
            }
            return;
        }
        if (event.name == "start") {
            this.index = 0;
        }
        if (event.name == "ok") {
        	event.target.box.modal('hide');
            this.index++;
            log("BenefitManager increased +1 for benefit index : ", this.index);
        }
        if ( event.name == "cancel") {
        	event.target.box.modal('hide');
            this.index++;
            log("BenefitManager increased +1 for benefit index : ", this.index);
        }
        if ((this.benefits.length - 1) < this.index) {
            log("Benefit Manager stop property set to true", {});
            this.stop = true;
        }
        if (this.stop === true) {
            log("Benefit Manager stoped. ", {});
            return;
        }
        this.run();


    };

    this.setPublisher = function (o) {
        this.publisher = o;
    };

}

function BenetifEventPublisher() {
    this.subscribers = [];
    this.subscribe = function (o) {
        o.setPublisher(this);
        this.subscribers.push(o);
    };
    this.unsubscribe = function (o) {
        this.subscribers.filter(
            function (item) {
                if (item !== o) {
                    return item;
                }
            }
        );
    };

    this.fire = function (event) {
        log("event fired ", event.name);
        this.subscribers.forEach(function (item) {
            item.update(event);
        });
    };
}

function PriorityQueue(callback){
    this.container = new Array();
    this.push = function (item){
        var inserted = false;
        for (var i = 0; this.container.length > i ; i++){
            var indexed = this.container[i];
            if (callback(item, indexed)){
                this.container.splice(i, 0, item);
                inserted = true;
                break;

            }
        }

        !inserted && this.container.push(item);
    }

}

// fire({name: "cancel", target: benefit});
function BenefitOkEvent(benefit){
	return {name :"ok", target: benefit};
}

function BenefitCancelEvent(benefit){

	return {name :"cancel", target: benefit};
}

function BenefitShowEvent(benefit){
	return {name :"show", target: benefit};
}