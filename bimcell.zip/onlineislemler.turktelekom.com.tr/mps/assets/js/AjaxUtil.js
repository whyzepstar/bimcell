/* For jQuery UI Loading Modal */
function newgetLoadingMessage(message)
{
	var html = [];
	html.push('<div class="start-overlay">');
		html.push('<img  style="width:128px;height:128px;" src="assets/images/loading.gif" />');
	html.push('</div>');
	return html.join('');
}
function blockUILoading(message) {
	$.blockUI({
		message: newgetLoadingMessage(message)
	});
}
/* thıs function is used in sendajaxpostf() just for show loading ! */
function newblockUILoading(message) {
	$.blockUI({
		message: newgetLoadingMessage(message)
	});
}
function blockUISuccess(message)
{
    ShowModalSuccess(message);
}
function blockUIFail(message)
{
    ShowModalAlert(message);
}
function unblockUI() {
	$.unblockUI();
}
function handleSessionTimeout(response) {
	var command = parseXml(response, "PortalRequestedCommand");
	if (command != null && command == "Login")
	window.location = "Portal?cmd=Login";
}
function sendFormRequest(myform, myUrl, useBlockUI) {
	if (useBlockUI) {
		blockUILoadingDefault();
	}
	try {
		var form = document.getElementById(myform);
		jQuery.ajaxSetup({
			'beforeSend': function (xhr) {
				xhr.setRequestHeader("ajax", "true")
			}
		})
		jQuery.ajax({
			type: 'POST',
			url: myUrl,
			data: $(form).serialize(),
			success: function (response) {
				handleSessionTimeout(response);
				successformcallback(response, myform);
			},
			error: function () {
				blockUIFailDefault();
			}
		});
	}
	catch (err) {
		blockUIFailDefault();
	}
}
function sendGetRequest(myUrl, myData, useBlockUI) {
	if (useBlockUI) {
		blockUILoadingDefault();
	}
	try {
		jQuery.ajaxSetup({
			'beforeSend': function (xhr) {
				xhr.setRequestHeader("ajax", "true")
			}
		})
		jQuery.ajax({
			type: 'GET',
			url: myUrl,
			data: myData,
			success: function (response) {
				handleSessionTimeout(response);
				successgetcallback(response);
			},
			error: function () {
				blockUIFailDefault();
			}
		});
	}
	catch (err) {
		blockUIFailDefault();
	}
}
function successgetcallbackdefault(response) {
	var stateResponse = "";
	unblockUI();
	var errorResponse = parseXml(response, "error");
	if (errorResponse != null && errorResponse != "") {
		blockUIFail(errorResponse);
	} else {
		var messageResponse = parseXml(response, "message");
		if (messageResponse != null && messageResponse != "") {
			blockUISuccess(messageResponse);
		}
	}
}
function blockUIFailDefault() {
	blockUIFail('\u0130\u015fleminiz ger\u00e7ekle\u015ftirilemiyor. L\u00fctfen daha sonra tekrar deneyiniz.');
}
function blockUILoadingDefault() {
	newblockUILoading('\u0130\u015fleminiz ger\u00e7ekle\u015ftiriliyor.');
}
function parseXml(xml, tag) {
	return $(xml).find(tag).text();
}
function hideElement(elementName) {
	document.getElementById(elementName).style.display = "none";
}
function showElement(elementName) {
	document.getElementById(elementName).style.display = "block";
}